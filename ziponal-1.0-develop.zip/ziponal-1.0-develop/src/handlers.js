const { loadConfig } = require('./confhandler');
const { loadLanguageFile } = require('./langshandler');

exports.loadConfig = loadConfig;
exports.loadLanguageFile = loadLanguageFile;