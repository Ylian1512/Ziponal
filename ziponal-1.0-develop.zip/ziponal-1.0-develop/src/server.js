const express = require('express');
const esession = require('express-session');

const path = require('path');
const crypt = require('crypto');
const { loadConfig, loadLanguageFile } = require('./handlers');

let config = loadConfig(path.join(__dirname, 'CONFIG.jsonc'));
setInterval(() => {
    config = loadConfig(path.join(__dirname, 'CONFIG.jsonc'));
}, 18000)

const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.use(esession(
    {
        cookie: { secure: false, signed: true, path: "/"  },
        saveUninitialized: true,
        resave: false,
        name: "token.ssid",
        secret: "YOUR_CUSTOM_SECRET_KEY"
    }
))

app.get('/', (req, res) => {
    res.render('index', { config, loadLanguageFile });
});

app.get('/adminpanel/config', (req, res) => {
    if (config) {
        res.render('config', { config });
    } else {
        res.status(500).send('Erreur lors du chargement de la configuration.');
    }
});

app.listen(port, () => {
    console.log(`Server launched in http://localhost:${port}`);
});
