"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.loadConfig = void 0;

const fs = require('fs');
const jsoncParser = require('jsonc-parser');
const path = require('path');

const validateConfig = (config) => {
    const errors = [];
    
    if (!Array.isArray(config.groups)) {
        errors.push("Les groupes doivent être un tableau.");
    } else {
        config.groups.forEach((group) => {
            if (!group.name || typeof group.name !== 'string') {
                errors.push("Chaque groupe doit avoir un nom valide.");
            }
            if (!Array.isArray(group.list)) {
                errors.push(`La liste des éléments dans le groupe ${group.name} doit être un tableau.`);
            } else {
                group.list.forEach((item) => {
                    if (typeof item === 'string') {
                        return;
                    }
                    if (!item.name || typeof item.name !== 'string') {
                        errors.push("Chaque élément dans la liste doit avoir un nom valide.");
                    }
                    if (!Array.isArray(item.type) || item.type.length === 0) {
                        errors.push("Chaque élément doit avoir au moins un type valide.");
                    }
                    if (!item.settings || typeof item.settings !== 'object') {
                        errors.push("Les paramètres de chaque élément doivent être un objet.");
                    }
                });
            }
        });
    }
    
    if (!config.permissions || typeof config.permissions !== 'object') {
        errors.push("Les permissions doivent être définies et être un objet.");
    }
    if (!Array.isArray(config.features)) {
        errors.push("Les fonctionnalités doivent être un tableau.");
    } else {
        config.features.forEach((feature) => {
            if (!feature.name || typeof feature.name !== 'string') {
                errors.push("Chaque fonctionnalité doit avoir un nom valide.");
            }
            if (typeof feature.enabled !== 'boolean' && feature.name !== "consoleCommands") {
                errors.push(`L'état de la fonctionnalité ${feature.name} doit être un boolean.`);
            }
            if (feature.settings && typeof feature.settings !== 'object') {
                errors.push(`Les paramètres de la fonctionnalité ${feature.name} doivent être un objet.`);
            }
        });
    }

    if (config.vpsSettings.ddns[0] === true) {
        fs.writeFileSync(path.join(__dirname, config.vpsSettings.ddns[1].type), config.vpsSettings.ddns[1].address, { encoding: "utf8" })
    } else {
        fs.unlink(config.vpsSettings.ddns[1].type, (err) => {
            fs.open(config.vpsSettings.ddns[1].type, () => {
                throw new Error("Error when deleting the DDNS file: " + err.message + `\n\nCode: ${err.code}`)
            })
        })
    }

    return errors;
};

const loadConfig = (filePath) => {
    try {
        const rawData = fs.readFileSync(filePath, 'utf8');
        const config = jsoncParser.parse(rawData);
        const validationErrors = validateConfig(config);
        if (validationErrors.length > 0) {
            console.error("Erreurs de validation de la configuration :", validationErrors);
            return null;
        }
        return config;
    }
    catch (error) {
        console.error("Erreur lors du chargement de la configuration :", error.message);
        return null;
    }
};

exports.loadConfig = loadConfig;