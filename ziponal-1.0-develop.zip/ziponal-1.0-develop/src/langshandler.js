const loadLanguageFile = (lang, region) => {
    const filePath = path.join(__dirname, 'public', 'lang', lang, region, 'messages.json');
    try {
        const rawData = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(rawData);
    } catch (error) {
        console.error(`Erreur lors du chargement des fichiers de langue: ${error.message}`);
        return null;
    }
};

exports.loadLanguageFile = loadLanguageFile;