console.log('Launching the server')
require('./src/server');