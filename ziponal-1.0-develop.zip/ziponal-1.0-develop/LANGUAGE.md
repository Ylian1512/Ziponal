# Welcome to the language discovery

## Language Library

Here, you can see all languages done by users or the team in this website: <https://befaci-dev.serveblog.net/library?filter={"template":"ziponal"}&theme=dark> (to request your language, please do it in our *FRENCH* Discord server: <https://befaci-dev.serveblog.net/discord>) (NOT DONE YET)
