# You just need to run the following command

`node launch.js`

**And the core of the VPS will be launched!**
